from fastapi import FastAPI, HTTPException
from db import init_db
from config import get_settings
from schemas.user import BaseUser, GetUsers, UpdateUser
from schemas.base import BaseResponse
from models.user import User

settings = get_settings()

app = FastAPI(
    title=settings.app_name,
    version=settings.app_version,
    description="FastAPI CRUD Tortoise-orm with aerich",
    debug=settings.app_debug,
)


@app.on_event("startup")
async def startup():
    await init_db()
    print("DB Connected ✅")


@app.post("/user", response_model=BaseResponse)
async def create_user(user: BaseUser):
    user_data = await User.create(
        name=user.name, email=user.email, username=user.username
    )

    data = {
        "name": user_data.name,
        "email": user_data.email,
        "username": user_data.username,
    }

    return BaseResponse(data=data)


@app.get("/get/users/", response_model=BaseResponse)
async def get_users():
    users = await User.all()
    data = [GetUsers.from_orm(user) for user in users]
    return BaseResponse(data=data)


@app.get('/get/user_id', response_model=BaseResponse)
async def get_user(user_id: int):
    user1 = await User.filter(id=user_id).all()
    if not user1:
        raise HTTPException(status_code=404, detail="User not found")
    data = [GetUsers.from_orm(user) for user in user1]
    return BaseResponse(data=data)


@app.put("/update/user", response_model=BaseResponse)
async def update_user(user: UpdateUser):
    await User.filter(id=user.id).update(
        name=user.name,
        email=user.email,
        username=user.username
    )

    user_data = await User.get(id=user.id)

    data = {
        "id": user_data.id,
        "name": user_data.name,
        "email": user_data.email,
        "username": user_data.username,
    }

    return BaseResponse(data=data)


@app.delete('/delete/user/{user_id}/', response_model=BaseResponse)
async def delete_user(user_id: int):
    await User.filter(id=user_id).delete()
    return {"ok": True}
