from tortoise import fields
from tortoise.models import Model


class Book(Model):
    id = fields.IntField(pk=True)
    author = fields.CharField(max_length=50)
    title = fields.CharField(max_length=100)
    description = fields.TextField()
    created_at = fields.DatetimeField(auto_now_add=True)