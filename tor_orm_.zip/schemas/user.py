from pydantic import BaseModel, EmailStr
from datetime import datetime


class BaseUser(BaseModel):
    name: str
    email: EmailStr
    username: str


class GetUsers(BaseModel):
    id: int
    name: str
    email: EmailStr
    username: str
    created_at: datetime

    class Config:
        from_attributes = True

class UpdateUser(BaseModel):
    id: int
    name: str
    email: EmailStr
    username: str
